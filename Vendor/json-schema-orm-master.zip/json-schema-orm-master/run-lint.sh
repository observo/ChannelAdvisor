#!/bin/sh -x
node-lint lib/ --config=lint.json
