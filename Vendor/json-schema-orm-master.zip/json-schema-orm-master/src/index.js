"use strict";
module.exports = {
	'build': require('./build.js'),
	'SchemaObject': require('./SchemaObject.js')
};
