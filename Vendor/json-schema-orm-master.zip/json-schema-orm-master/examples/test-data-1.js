"use strict";
module.exports = {
	"name": "Test data",
	"date": "2013-09-02T05:48:41",
	"points": [
		{"x":10, "y":20},
		{"x":20, "y":30},
		{"x":30, "y":40}
	]
};
