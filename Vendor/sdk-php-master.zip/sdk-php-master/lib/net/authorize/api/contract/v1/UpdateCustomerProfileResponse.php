<?php

namespace net\authorize\api\contract\v1;

/**
 * Class representing UpdateCustomerProfileResponse
 */
class UpdateCustomerProfileResponse extends ANetApiResponseType
{


}

