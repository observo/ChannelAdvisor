<?php

namespace net\authorize\api\contract\v1;

/**
 * Class representing ProfileTransAuthOnlyType
 *
 *
 * XSD Type: profileTransAuthOnlyType
 */
class ProfileTransAuthOnlyType extends ProfileTransOrderType
{


}

